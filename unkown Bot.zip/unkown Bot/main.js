// ================== TEMP FIX (ENOSPC SAFE) ==================
const fs = require('fs')
const path = require('path')

const customTemp = path.join(process.cwd(), 'temp')
if (!fs.existsSync(customTemp)) fs.mkdirSync(customTemp, { recursive: true })

process.env.TMPDIR = customTemp
process.env.TEMP = customTemp
process.env.TMP = customTemp

setInterval(() => {
    fs.readdir(customTemp, (err, files) => {
        if (err) return
        for (const file of files) {
            const filePath = path.join(customTemp, file)
            fs.stat(filePath, (err, stats) => {
                if (!err && Date.now() - stats.mtimeMs > 3 * 60 * 60 * 1000) {
                    fs.unlink(filePath, () => {})
                }
            })
        }
    })
    console.log('🧹 Temp cleaned')
}, 3 * 60 * 60 * 1000)

// ================== CORE IMPORTS ==================
require('./config')
const settings = require('./settings')

const { channelInfo } = require('./lib/messageConfig')
const { isBanned } = require('./lib/isBanned')
const isAdmin = require('./lib/isAdmin')
const isOwnerOrSudo = require('./lib/isOwner')
const { isSudo } = require('./lib/index')

// ================== GLOBAL BRANDING ==================
global.packname = 'Unknown Bot'
global.author = 'Private27'
global.channelLink = 'https://whatsapp.com/channel/0029Va90zAnIHphOuO8Msp3A'
global.ytch = 'Private27'

// ================== COMMAND IMPORTS ==================
const helpCommand = require('./commands/help')
const banCommand = require('./commands/ban')
const unbanCommand = require('./commands/unban')
const muteCommand = require('./commands/mute')
const unmuteCommand = require('./commands/unmute')
const kickCommand = require('./commands/kick')
const tagAllCommand = require('./commands/tagall')
const ownerCommand = require('./commands/owner')
const pingCommand = require('./commands/ping')
const aliveCommand = require('./commands/alive')

// Moderation
const { handleBadwordDetection } = require('./lib/antibadword')
const { Antilink } = require('./lib/antilink')

// ================== MESSAGE HANDLER ==================
async function handleMessages(sock, messageUpdate) {
    try {
        if (messageUpdate.type !== 'notify') return
        const message = messageUpdate.messages[0]
        if (!message?.message) return

        const chatId = message.key.remoteJid
        const senderId = message.key.participant || chatId
        const isGroup = chatId.endsWith('@g.us')

        const body =
            message.message?.conversation ||
            message.message?.extendedTextMessage?.text ||
            message.message?.imageMessage?.caption ||
            message.message?.videoMessage?.caption ||
            ''

        const text = body.trim()
        const lower = text.toLowerCase()

        // ================== BAN CHECK ==================
        if (await isBanned(senderId)) {
            return sock.sendMessage(chatId, {
                text: '❌ You are banned from using this bot.',
                ...channelInfo
            })
        }

        // ================== MODERATION ==================
        if (isGroup && lower) {
            await handleBadwordDetection(sock, chatId, message, lower, senderId)
            await Antilink(message, sock)
        }

        // ================== PREFIX CHECK ==================
        if (!lower.startsWith('.')) return

        const senderIsOwner = message.key.fromMe || await isOwnerOrSudo(senderId, sock, chatId)
        const senderIsSudo = await isSudo(senderId)

        // ================== ADMIN CHECK ==================
        let adminStatus = { isSenderAdmin: false, isBotAdmin: false }
        if (isGroup) {
            adminStatus = await isAdmin(sock, chatId, senderId)
        }

        // ================== COMMAND ROUTER ==================
        switch (true) {

            case lower === '.menu':
            case lower === '.help':
                return helpCommand(sock, chatId, message, channelInfo)

            case lower === '.ping':
                return pingCommand(sock, chatId)

            case lower === '.alive':
                return aliveCommand(sock, chatId)

            case lower.startsWith('.ban'):
                if (!senderIsSudo && !senderIsOwner) return
                return banCommand(sock, chatId, message)

            case lower.startsWith('.unban'):
                if (!senderIsSudo && !senderIsOwner) return
                return unbanCommand(sock, chatId, message)

            case lower.startsWith('.mute'):
                if (!adminStatus.isSenderAdmin) return
                return muteCommand(sock, chatId, senderId, message)

            case lower === '.unmute':
                if (!adminStatus.isSenderAdmin) return
                return unmuteCommand(sock, chatId, senderId)

            case lower.startsWith('.kick'):
                if (!adminStatus.isSenderAdmin) return
                return kickCommand(sock, chatId, senderId, message)

            case lower === '.tagall':
                if (!adminStatus.isSenderAdmin) return
                return tagAllCommand(sock, chatId)

            case lower === '.owner':
                return ownerCommand(sock, chatId)

        }

    } catch (err) {
        console.error('❌ Main.js Error:', err)
    }
}

module.exports = {
    handleMessages
}