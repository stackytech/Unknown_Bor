require('./settings')
const { Boom } = require('@hapi/boom')
const fs = require('fs')
const chalk = require('chalk')
const path = require('path')
const crypto = require('crypto')
const axios = require('axios')

const { handleMessages, handleGroupParticipantUpdate, handleStatus } = require('./main')
const PhoneNumber = require('awesome-phonenumber')

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    jidDecode,
    jidNormalizedUser,
    makeCacheableSignalKeyStore,
    delay
} = require('@whiskeysockets/baileys')

const NodeCache = require('node-cache')
const pino = require('pino')
const readline = require('readline')
const { rmSync } = require('fs')

const store = require('./lib/lightweight_store')
store.readFromFile()

const settings = require('./settings')
setInterval(() => store.writeToFile(), 10000)

/* ================= GLOBAL BRANDING ================= */
global.botname = 'Unknown Bot'
global.botcredit = 'Developed by Private27'
global.themeemoji = '•'

/* ================= KEY STORAGE ================= */
const CLIENT_DB = './data/clients.json'
if (!fs.existsSync(CLIENT_DB)) fs.writeFileSync(CLIENT_DB, JSON.stringify({}))

function generateKey() {
    return crypto.randomBytes(24).toString('hex')
}

function saveClient(number, key) {
    const db = JSON.parse(fs.readFileSync(CLIENT_DB))
    db[number] = {
        key,
        created: Date.now()
    }
    fs.writeFileSync(CLIENT_DB, JSON.stringify(db, null, 2))
}

/* ================= START BOT ================= */
async function startUnknownBot() {
    try {
        const { version } = await fetchLatestBaileysVersion()
        const { state, saveCreds } = await useMultiFileAuthState('./session')
        const msgRetryCounterCache = new NodeCache()

        const sock = makeWASocket({
            version,
            logger: pino({ level: 'silent' }),
            printQRInTerminal: true,
            browser: ['Unknown Bot', 'Chrome', '1.0'],
            auth: {
                creds: state.creds,
                keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'fatal' }))
            },
            markOnlineOnConnect: true,
            generateHighQualityLinkPreview: true,
            msgRetryCounterCache,
            getMessage: async (key) => {
                const jid = jidNormalizedUser(key.remoteJid)
                const msg = await store.loadMessage(jid, key.id)
                return msg?.message || ''
            }
        })

        sock.ev.on('creds.update', saveCreds)
        store.bind(sock.ev)

        /* ================= CONNECTION ================= */
        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect } = update

            if (connection === 'open') {
                const number = sock.user.id.split(':')[0]
                const jid = number + '@s.whatsapp.net'

                const privateKey = generateKey()
                saveClient(number, privateKey)

                console.log(chalk.green('✅ Unknown Bot connected'))
                console.log(chalk.cyan(`🔐 Private Key: ${privateKey}`))

                await sock.sendMessage(jid, {
                    text:
`🤖 *${global.botname}*

✅ Connected successfully
📱 Number: ${number}
🔐 Private Key:
${privateKey}

🌐 Dashboard: coming soon
📢 Join our channel below

_${global.botcredit}_`,
                    contextInfo: {
                        forwardingScore: 1,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: '0029Vb6vJIW6GcGJ0Ussfq01@newsletter',
                            newsletterName: 'Unknown Bot Channel',
                            serverMessageId: -1
                        }
                    }
                })

                console.log(chalk.magenta(`\n[ ${global.botname} ]`))
                console.log(chalk.green(`${global.themeemoji} ${global.botcredit}`))
                console.log(chalk.green(`${global.themeemoji} Bot is online\n`))
            }

            if (connection === 'close') {
                const statusCode = lastDisconnect?.error?.output?.statusCode
                const shouldReconnect = statusCode !== DisconnectReason.loggedOut

                console.log(chalk.red('❌ Connection closed'))

                if (statusCode === DisconnectReason.loggedOut) {
                    rmSync('./session', { recursive: true, force: true })
                    console.log(chalk.yellow('Session cleared. Re-pair required.'))
                }

                if (shouldReconnect) {
                    await delay(5000)
                    startUnknownBot()
                }
            }
        })

        /* ================= MESSAGE HANDLER ================= */
        sock.ev.on('messages.upsert', async (chatUpdate) => {
            const msg = chatUpdate.messages[0]
            if (!msg.message) return
            await handleMessages(sock, chatUpdate, true)
        })

        sock.ev.on('group-participants.update', async (update) => {
            await handleGroupParticipantUpdate(sock, update)
        })

        sock.ev.on('status.update', async (status) => {
            await handleStatus(sock, status)
        })

        return sock
    } catch (err) {
        console.error('Fatal start error:', err)
        await delay(5000)
        startUnknownBot()
    }
}

startUnknownBot()

process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)